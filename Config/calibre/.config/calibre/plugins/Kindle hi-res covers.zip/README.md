A Calibre plug-in to download high-resolution cover images from Amazon.
Only Kindle books are supported.

This plug-in uses the technique published at:
https://www.ereader-palace.com/get-high-resolution-cover-image-amazon-kindle-ebooks/

---

Note that the lack of activity does not mean that this plug-in is dead — on the contrary, this plug-in is meant to do one job and do it well, and it is deliberately kept simple to require little or no maintenance. The lack of activity means that it is fulfilling its goals.

If future changes to Calibre and/or Amazon require an update, then it will be updated accordingly.
